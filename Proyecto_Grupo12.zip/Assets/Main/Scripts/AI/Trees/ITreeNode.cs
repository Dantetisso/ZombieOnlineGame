using UnityEngine;

public interface ITreeNode
{
    void Execute();
}
