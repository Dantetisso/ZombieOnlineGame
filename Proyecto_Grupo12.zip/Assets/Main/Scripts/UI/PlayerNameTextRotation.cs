using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerNameTextRotation : MonoBehaviour
{
    void LateUpdate()
    {
        transform.rotation = Quaternion.identity;
    }
}
