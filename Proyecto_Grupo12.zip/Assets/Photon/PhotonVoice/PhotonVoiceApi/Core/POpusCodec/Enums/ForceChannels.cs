﻿namespace POpusCodec.Enums
{
    public enum ForceChannels : int
    {
        NoForce = -1000,
        Mono = 1,
        Stereo = 2
    }
}
