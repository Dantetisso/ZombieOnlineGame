
This is the readme for the Photon Voice API.
(C) Exit Games GmbH 2024


Overview
----------------------------------------------------------------------------------------------------
Photon Voice API is designed to implement clients for room-based media streaming applications. Each client can broadcast multiple media streams to a room where other connected clients can receive these streams.
Bundled with Photon Realtime API, Photon Voice extends it with streaming capabilities while retaining all Realtime features: lobbies, rooms, players, etc.
